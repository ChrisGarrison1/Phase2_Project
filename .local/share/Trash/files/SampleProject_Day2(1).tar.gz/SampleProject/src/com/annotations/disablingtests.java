package com.annotations;

import org.testng.annotations.Test;

public class disablingtests {
	
	@Test(enabled=false)
	public void TestMethod1() {
		
	}

}
