package com.annotations;

import org.testng.annotations.Test;

public class TestAnnotations2 {
	@Test
	public void Login() throws Exception {
		System.out.println("Login");
		throw new Exception("Login Failed");
	}

	@Test(alwaysRun=true,dependsOnMethods="Login")
	public void AccountEnquiry() {
	System.out.println("AccountEnquiry");
	}
	
	@Test(alwaysRun=true,dependsOnMethods="Login")
	public void FundTransfer() {
		System.out.println("FundTransfer");
	}
}
